#[derive(Debug)]
pub struct TribonacciError(pub String);