/*
a and b (they both are mutable) reference vec at the same time. 
Since Rust prevents data races where two or more threads attempt to modify the same data at the same time,
this program cannot be compiled.
 */


fn main() {
    let mut vec = vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

    let a = &mut vec;
    a.push(11);
    let b = &mut vec;
    b.push(12);
}

/*
After modifing, only one mutable reference. 
Another one references to the date after the previous one goes out of scope.
 */