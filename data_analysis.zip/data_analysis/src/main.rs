const ENROLMENTS_PATH: &str = "enrolments.psv";
use serde::Deserialize;
use csv::ReaderBuilder;
use std::collections::{HashMap, HashSet};
use std::fs::File;

#[derive(Deserialize, Debug, Clone)]
struct Table {
    course_code: String,
    student_id: u32,
    name: String,
    program: String,
    plan: String,
    wam: f32,
    session: String,
    birthday: String,
    sex: String,
}

fn main() {
    let mut rdr = ReaderBuilder::new()
        .delimiter(b'|')
        .has_headers(false)
        .from_path(ENROLMENTS_PATH)
        .unwrap();

    let enrolments = rdr.deserialize::<Table>()
        .filter_map(|result| result.ok())
        .collect::<Vec<Table>>();

    let mut students: HashSet<_> = enrolments.iter().map(|e| e.student_id).collect();
    println!("Number of students: {}", students.len());

    let mut course_student: HashMap<_, HashSet<_>> = HashMap::new();
    for enrolment in &enrolments {
        course_student
            .entry(enrolment.course_code.clone())
            .or_default()
            .insert(enrolment.student_id);
    }
    let (max_course, max_student) = course_student
        .iter()
        .max_by_key(|(_, students)| students.len())
        .unwrap();
    let (min_course, min_student) = course_student
        .iter()
        .min_by_key(|(_, students)| students.len())
        .unwrap();
    println!(
        "Most common course: {} with {} students",
        max_course,
        max_student.len()
    );
    println!(
        "Least common course: {} with {} students",
        min_course,
        min_student.len()
    );

    // WAM
    let wam:HashMap<u32, f32> = enrolments.iter().map(|enrolment| {
        (enrolment.student_id, enrolment.wam)
    }).collect();
    let total_wam = wam.values().sum::<f32>();
    let avg_wam = total_wam / wam.len() as f32;
    println!("Average WAM: {:.2}", avg_wam);
}