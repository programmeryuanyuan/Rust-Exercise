use std::env;
use bmp::{Image, Pixel};
use bmp::consts;

fn main() {
    for arg in env::args().skip(1) {
        match bmp::open(arg.clone()) {
            Ok(img) => {
                println!("===== {} =====", arg);
                for x in 0..=img.get_height()-1 {
                    for y in 0..=img.get_width()-1 {
                        let pixel = img.get_pixel(y,x);
                            let color = match pixel {
                                bmp::consts::RED => 'R',
                                bmp::consts::LIME => 'G',
                                bmp::consts::BLUE => 'B',
                                bmp::consts::WHITE => 'W',
                                _ => '?',
                            };
                            print!("{} ", color);
                    }
                    println!();
                }
            }
            Err(e) => {
                println!("===== {} =====", arg);
                println!("Error! {:?}", e);
                continue;
            }
        };
    };    
}

