use std::collections::VecDeque;

const MAX_ITER: i32 = 300000;

fn main() {
    // Vectors
    vec_operations();

    // VecDeque
    vec_deque_operations();

    // LinkedList
    // TODO: your code here, for linked list insertions
    linked_list_operations();

    // HashMap
    // TODO: your code here, for hashmap insertions
    hash_map_operation();

    // TODO: your text explanation to the questions in the spec
    /*
    1.Which collection type was the fastest for adding and removing elements?
    (VecDeque > Linkedlist > Vector)
    VecDeque is double-ended queue and does not need a separate allocation and deallocation of memory for each element.

    2.Why do you think this was the case?
    VecDeque is doubleended queue so it is efficient to insert or delete at both ends.
    
    3.Is there any significant difference between Vec and VecDeque deletion?
    If so, why? If not, why not?
    Yes. 
    Vectors store their elements in a contiguous block of memory. The access time complexity is O(c). But for insertion or deletion, it require elements shifting.
    VecDeque is efficient for insertion or deletion but since it dosen't store elements in contiguous memory. The accessing is less efficient.
    
    4.When would you consider using VecDeque over Vec?
    When I have to do a lot of insertion or removal  but less accessing to the collection.

    5.When would you consider using LinkedList over Vec?
    LinkedList has pointers to the previous and next nodes in the list. It is also efficient for insertion and deletion. But accessing elements by index needs to traversing the list, it has larger time complexity for accesing compared to Vectors.
    So, I would consider using LinkedList over Vec when I have to do a lot of insertion or removal but less accessing the collection.

    6.Did the results suprise you? Why or why not?
    No, since I have foundations about data structure. I'm quite clear about their performance characteristics and use cases.
*/
}

/// measure the insertion and removal
/// operations of a vector
fn vec_operations() {
    let mut vec = Vec::new();

    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER {
        vec.push(i);
    }
    let time_end = std::time::Instant::now();

    println!("==== Vector ====");
    println!("insert: {:?}", time_end - time_start);

    let time_start = std::time::Instant::now();
    for _ in 0..MAX_ITER {
        vec.remove(0);
    }
    let time_end = std::time::Instant::now();

    println!("remove: {:?}", time_end - time_start);
}

/// measure the insertion and removal
/// operations of a VecDeque
fn vec_deque_operations() {
    let mut vec_deque = VecDeque::new();

    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER {
        vec_deque.push_back(i);
    }
    let time_end = std::time::Instant::now();

    println!("==== VecDeque ====");
    println!("insert: {:?}", time_end - time_start);

    let time_start = std::time::Instant::now();
    for _ in 0..MAX_ITER {
        vec_deque.pop_front();
    }
    let time_end = std::time::Instant::now();

    println!("remove: {:?}", time_end - time_start);
}

fn linked_list_operations() {
    let mut linked_list = LinkedList::new();

    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER {
        linked_list.push_back(i);
    }
    let time_end = std::time::Instant::now();

    println!("==== LinkedList ====");
    println!("insert: {:?}", time_end - time_start);

    let time_start = std::time::Instant::now();
    for _ in 0..MAX_ITER {
        linked_list.pop_front();
    }
    let time_end = std::time::Instant::now();

    println!("remove: {:?}", time_end - time_start);
}

fn hash_map_operation() {
    let mut hash_map:HashMap<i32, ()> = HashMap::new();
    
    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER {
        hash_map.insert(i, ());
    }
    let time_end = std::time::Instant::now();

    println!("==== HashMap ====");
    println!("insert: {:?}", time_end - time_start);

    let time_start = std::time::Instant::now();
    for i in 0..MAX_ITER {
        hash_map.remove(&i);
    }
    let time_end = std::time::Instant::now();

    println!("remove: {:?}", time_end - time_start);
}

